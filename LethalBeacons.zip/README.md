# Adds a beacon to the shop to help you navigate in poor visibility.

## Information
This mod adds a beacon to the terminal shop. This beacon can be scanned from a large distance, enabling you to navigate back to where you want to be.
- Especially useful in poor weather conditions
- Configurable prices
- Default price $75
- Weight 12lb

### 1.2.0
- Added configurable prices

### 1.0.1
- Fixed Shop Prices

### 1.0.0
- Initial Release